async function loadCoins() {

    const container =
        document.getElementById(
            "coinsContainer"
        );

    try {

        container.innerHTML =
            createLoadingCards();

        const response = await fetch(
            `${API_BASE_URL}/market/coins`
        );

        if (!response.ok) {

            throw new Error(
                "Erro ao buscar mercado"
            );

        }

        const coins =
            await response.json();

        updateHeroMetrics(coins);

        updateGlobalStats(coins);

        container.innerHTML =
            coins.map(coin => {

                const sentimentClass =
                    getSentimentClass(
                        coin.sentimentScore
                    );

                const trendClass =
                    coin.change24h >= 0
                        ? "positive"
                        : "negative";

                const trendIcon =
                    coin.change24h >= 0
                        ? "▲"
                        : "▼";

                return `

                    <div class="coin-card">

                        <div class="coin-header">

                            <div class="coin-identity">

                                <img
                                    src="${coin.image}"
                                    alt="${coin.name}"
                                    onerror="
                                        this.src='https://via.placeholder.com/40'
                                    "
                                >

                                <div>

                                    <div class="coin-name">
                                        ${coin.name}
                                    </div>

                                    <div class="coin-symbol">
                                        ${coin.symbol.toUpperCase()}
                                    </div>

                                </div>

                            </div>

                            <div class="
                                trend-badge
                                ${trendClass}
                            ">
                                ${trendIcon}
                                ${coin.change24h?.toFixed(2)}%
                            </div>

                        </div>

                        <div class="coin-body">

                            <div class="metric">

                                <span>
                                    Preço
                                </span>

                                <strong>
                                    ${formatCurrency(
                                        coin.price
                                    )}
                                </strong>

                            </div>

                            <div class="metric">

                                <span>
                                    Market Cap
                                </span>

                                <strong>
                                    $${formatNumber(
                                        coin.marketCap
                                    )}
                                </strong>

                            </div>

                            <div class="metric">

                                <span>
                                    Volume 24H
                                </span>

                                <strong>
                                    $${formatNumber(
                                        coin.volume24h || 0
                                    )}
                                </strong>

                            </div>

                            <div class="metric">

                                <span>
                                    Sentimento
                                </span>

                                <strong class="
                                    ${sentimentClass}
                                ">
                                    ${formatSentiment(
                                        coin.sentimentScore
                                    )}
                                </strong>

                            </div>

                        </div>

                    </div>

                `;

            }).join("");

    } catch (error) {

        console.error(error);

        container.innerHTML = `

            <div class="error-box">

                <h3>
                    Falha na conexão com mercado
                </h3>

                <p>
                    Não foi possível carregar os dados.
                </p>

            </div>

        `;

    }

}

async function loadNews() {

    const container =
        document.getElementById(
            "newsContainer"
        );

    try {

        container.innerHTML = `

            <div class="mini-loading">
                Carregando narrativas...
            </div>

        `;

        const response = await fetch(
            `${API_BASE_URL}/market/news`
        );

        if (!response.ok) {

            throw new Error(
                "Erro ao carregar notícias"
            );

        }

        const news =
            await response.json();

        if (!news.length) {

            container.innerHTML = `

                <div class="mini-error">

                    Nenhuma narrativa encontrada

                </div>

            `;

            return;

        }

        container.innerHTML =
            news.map(article => {

                const sentimentClass =
                    article.sentiment === "positive"
                        ? "sentiment-positive"
                        : article.sentiment === "negative"
                            ? "sentiment-negative"
                            : "sentiment-neutral";

                return `

                    <div class="news-mini-card">

                        <div class="news-mini-top">

                            <div class="
                                news-sentiment
                                ${sentimentClass}
                            ">

                                ${translateSentiment(
                                    article.sentiment
                                )}

                            </div>

                            <span class="news-impact">

                                Impacto:
                                ${article.sentimentScore || 0}

                            </span>

                        </div>

                        <h4 class="news-mini-title">

                            ${article.title || "Sem título"}

                        </h4>

                        <div class="news-mini-footer">

                            <span>

                                ${article.source || "Crypto News"}

                            </span>

                            <span>

                                ${formatDate(
                                    article.publishedAt
                                )}

                            </span>

                        </div>

                    </div>

                `;

            }).join("");

    } catch (error) {

        console.error(error);

        container.innerHTML = `

            <div class="mini-error">

                Erro ao carregar notícias

            </div>

        `;

    }

}

function updateHeroMetrics(coins) {

    const totalCoins =
        document.getElementById(
            "totalCoins"
        );

    const marketSentiment =
        document.getElementById(
            "marketSentiment"
        );

    const lastUpdate =
        document.getElementById(
            "lastUpdate"
        );

    if (totalCoins) {

        totalCoins.textContent =
            coins.length;

    }

    const avgSentiment =
        coins.reduce(
            (acc, coin) =>
                acc + (
                    coin.sentimentScore || 0
                ),
            0
        ) / coins.length;

    if (marketSentiment) {

        marketSentiment.textContent =
            avgSentiment > 5
                ? "OTIMISTA"
                : avgSentiment < -5
                    ? "PESSIMISTA"
                    : "NEUTRO";

    }

    if (lastUpdate) {

        lastUpdate.textContent =
            new Date().toLocaleTimeString(
                "pt-BR"
            );

    }

}

function updateGlobalStats(coins) {

    const marketCapElement =
        document.getElementById(
            "marketCapGlobal"
        );

    const marketVolumeElement =
        document.getElementById(
            "marketVolume"
        );

    const btcElement =
        document.getElementById(
            "btcDominance"
        );

    const fearGreedElement =
        document.getElementById(
            "fearGreed"
        );

    const totalMarketCap =
        coins.reduce(
            (acc, coin) =>
                acc + (
                    coin.marketCap || 0
                ),
            0
        );

    const totalVolume =
        coins.reduce(
            (acc, coin) =>
                acc + (
                    coin.volume24h || 0
                ),
            0
        );

    const avgSentiment =
        coins.reduce(
            (acc, coin) =>
                acc + (
                    coin.sentimentScore || 0
                ),
            0
        ) / coins.length;

    if (marketCapElement) {

        marketCapElement.textContent =
            "$" +
            formatNumber(totalMarketCap);

    }

    if (marketVolumeElement) {

        marketVolumeElement.textContent =
            "$" +
            formatNumber(totalVolume);

    }

    if (btcElement) {

        const btc =
            coins.find(
                coin =>
                    coin.symbol.toLowerCase() === "btc"
            );

        btcElement.textContent =
            btc
                ? "52.4%"
                : "--";

    }

    if (fearGreedElement) {

        fearGreedElement.textContent =
            avgSentiment > 5
                ? "GANÂNCIA"
                : avgSentiment < -5
                    ? "MEDO"
                    : "NEUTRO";

    }

}

function translateSentiment(sentiment) {

    if (sentiment === "positive") {

        return "POSITIVO";

    }

    if (sentiment === "negative") {

        return "NEGATIVO";

    }

    return "NEUTRO";

}

function getSentimentClass(score) {

    if (score > 0) {

        return "sentiment-positive";

    }

    if (score < 0) {

        return "sentiment-negative";

    }

    return "sentiment-neutral";

}

function formatCurrency(value) {

    return new Intl.NumberFormat(
        "en-US",
        {
            style: "currency",
            currency: "USD",
            maximumFractionDigits: 2
        }
    ).format(value || 0);

}

function formatNumber(number) {

    return new Intl.NumberFormat(
        "en-US"
    ).format(number || 0);

}

function formatSentiment(score) {

    if (score > 5) {

        return `OTIMISTA (${score})`;

    }

    if (score < -5) {

        return `PESSIMISTA (${score})`;

    }

    return `NEUTRO (${score})`;

}

function formatDate(date) {

    if (!date) {

        return "--";

    }

    return new Date(date)
        .toLocaleString(
            "pt-BR",
            {
                day: "2-digit",
                month: "2-digit",
                hour: "2-digit",
                minute: "2-digit"
            }
        );

}

function createLoadingCards() {

    return `

        <div class="loading-card"></div>
        <div class="loading-card"></div>
        <div class="loading-card"></div>
        <div class="loading-card"></div>

    `;

}

loadCoins();

loadNews();

setInterval(() => {

    loadCoins();

}, 1000 * 30);

setInterval(() => {

    loadNews();

}, 1000 * 20);