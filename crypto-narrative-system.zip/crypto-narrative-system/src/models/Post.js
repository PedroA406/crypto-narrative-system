const mongoose = require('mongoose');

const postSchema = new mongoose.Schema({

  title: {
    type: String,
    required: true
  },

  content: {
    type: String,
    default: ''
  },

  source: {
    type: String,
    required: true
  },

  coin: {
    type: String,
    required: true
  },

  sentiment: {
    type: String,
    enum: ['positive', 'negative', 'neutral'],
    default: 'neutral'
  },

  sentimentScore: {
    type: Number,
    default: 0
  },

  url: {
    type: String,
    default: ''
  },

  publishedAt: {
    type: Date,
    default: Date.now
  }

}, {
  timestamps: true
});

module.exports = mongoose.model('Post', postSchema);