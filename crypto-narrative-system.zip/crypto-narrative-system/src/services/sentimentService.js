const positiveWords = [
    "bullish",
    "surge",
    "pump",
    "moon",
    "breakout",
    "gain",
    "rise",
    "rally",
    "strong",
    "buy",
    "profit",
    "growth",
    "high",
    "uptrend"
];

const negativeWords = [
    "bearish",
    "dump",
    "crash",
    "fall",
    "drop",
    "fear",
    "panic",
    "sell",
    "loss",
    "weak",
    "downtrend",
    "liquidation",
    "scam"
];

function analyzeSentiment(text) {

    if (!text) {
        return {
            sentiment: "neutral",
            score: 0
        };
    }

    const content = text.toLowerCase();

    let score = 0;

    positiveWords.forEach(word => {

        if (content.includes(word)) {
            score += 10;
        }

    });

    negativeWords.forEach(word => {

        if (content.includes(word)) {
            score -= 10;
        }

    });

    let sentiment = "neutral";

    if (score > 0) {
        sentiment = "positive";
    }

    if (score < 0) {
        sentiment = "negative";
    }

    return {
        sentiment,
        score
    };
}

module.exports = {
    analyzeSentiment
};