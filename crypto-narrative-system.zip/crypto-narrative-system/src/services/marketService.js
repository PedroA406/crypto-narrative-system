const Coin = require("../models/Coin");

const Post = require("../models/Post");

/*
|--------------------------------------------------------------------------
| GET ALL COINS
|--------------------------------------------------------------------------
| Retorna todas as moedas ordenadas por Market Cap
| Preparado para dashboard, rankings e APIs públicas
|--------------------------------------------------------------------------
*/

async function getAllCoins() {

    try {

        const coins = await Coin.find()
            .sort({ marketCap: -1 });

        return coins;

    } catch (error) {

        console.log("ERRO AO BUSCAR MOEDAS:");
        console.log(error.message);

        throw new Error(error.message);

    }

}

/*
|--------------------------------------------------------------------------
| GET COIN BY SYMBOL
|--------------------------------------------------------------------------
| Busca moeda específica:
| BTC
| ETH
| SOL
|--------------------------------------------------------------------------
*/

async function getCoinBySymbol(symbol) {

    try {

        const coin = await Coin.findOne({
            symbol: symbol.toLowerCase()
        });

        return coin;

    } catch (error) {

        console.log("ERRO AO BUSCAR MOEDA:");
        console.log(error.message);

        throw new Error(error.message);

    }

}

/*
|--------------------------------------------------------------------------
| UPDATE MARKET SENTIMENT
|--------------------------------------------------------------------------
| Calcula média de sentimento baseada nas notícias
| e atualiza o sentimentScore da moeda
|--------------------------------------------------------------------------
*/

async function updateMarketSentiment() {

    try {

        console.log("=================================");
        console.log("ATUALIZANDO SENTIMENTO DAS MOEDAS");
        console.log("=================================");

        const coins = await Coin.find();

        for (const coin of coins) {

            const posts = await Post.find({
                coin: coin.symbol.toUpperCase()
            });

            if (posts.length === 0) {

                console.log(
                    `Sem posts para ${coin.symbol}`
                );

                continue;
            }

            let totalScore = 0;

            posts.forEach(post => {

                totalScore += post.sentimentScore;

            });

            const averageScore =
                totalScore / posts.length;

            coin.sentimentScore =
                Math.round(averageScore);

            await coin.save();

            console.log(
                `${coin.name} → Sentiment Score: ${coin.sentimentScore}`
            );

        }

        console.log("=================================");
        console.log("SENTIMENTOS ATUALIZADOS");
        console.log("=================================");

    } catch (error) {

        console.log(
            "ERRO AO ATUALIZAR SENTIMENTO:"
        );

        console.log(error.message);

    }

}

/*
|--------------------------------------------------------------------------
| MODULE EXPORTS
|--------------------------------------------------------------------------
*/

module.exports = {
    getAllCoins,
    getCoinBySymbol,
    updateMarketSentiment
};