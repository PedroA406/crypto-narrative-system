const express = require("express");

const router = express.Router();

const {

    getCoins,
    getNews

} = require("../controllers/marketController");

router.get("/coins", getCoins);

router.get("/news", getNews);

module.exports = router;