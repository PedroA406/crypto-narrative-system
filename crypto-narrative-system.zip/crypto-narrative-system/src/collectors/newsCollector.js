const axios = require("axios");

const Post = require("../models/Post");

const {
    analyzeSentiment
} = require("../services/sentimentService");

async function collectNews() {

    try {

        console.log("=================================");
        console.log("COLETANDO NOTÍCIAS CRIPTO...");
        console.log("=================================");

        const response = await axios.get(
            "https://api.freenewsapi.io/v1/news",
            {
                headers: {
                    "x-api-key":
                        process.env.FREE_NEWS_API_KEY
                },

                params: {
                    language: "en",
                    q: "crypto OR bitcoin OR ethereum OR solana",
                    page_size: 10
                }
            }
        );

        const articles = response.data.data;

        console.log(
            `TOTAL DE NOTÍCIAS: ${articles.length}`
        );

        for (const article of articles) {

            const title =
                article.title || "";

            const description =
                article.description || "";

            const fullText =
                `${title} ${description}`;

            const sentimentResult =
                analyzeSentiment(fullText);

            const savedPost =
                await Post.findOneAndUpdate(

                    {
                        url: article.url
                    },

                    {
                        title: title,

                        content: description,

                        source:
                            article.publisher ||
                            "FreeNewsAPI",

                        coin:
                            detectCoin(fullText),

                        url: article.url,

                        sentiment:
                            sentimentResult.sentiment,

                        sentimentScore:
                            sentimentResult.score,

                        publishedAt:
                            article.published_at
                    },

                    {
                        upsert: true,
                        returnDocument: "after"
                    }
                );

            console.log("=================================");
            console.log(`📰 ${savedPost.title}`);
            console.log(
                `💭 Sentimento: ${savedPost.sentiment}`
            );
            console.log(
                `📊 Score: ${savedPost.sentimentScore}`
            );

        }

        console.log("=================================");
        console.log("COLETA FINALIZADA");
        console.log("=================================");

    } catch (error) {

        console.log("ERRO NEWS COLLECTOR:");

        if (error.response) {

            console.log(error.response.data);

        } else {

            console.log(error.message);

        }

    }

}

function detectCoin(text) {

    const content = text.toLowerCase();

    const coinMap = {

        BTC: [
            "bitcoin",
            "btc"
        ],

        ETH: [
            "ethereum",
            "eth"
        ],

        SOL: [
            "solana",
            "sol"
        ],

        XRP: [
            "xrp",
            "ripple"
        ],

        DOGE: [
            "dogecoin",
            "doge"
        ]

    };

    for (const coin in coinMap) {

        const keywords = coinMap[coin];

        for (const keyword of keywords) {

            if (content.includes(keyword)) {

                return coin;

            }

        }

    }

    return "GENERAL";
}

module.exports = collectNews;