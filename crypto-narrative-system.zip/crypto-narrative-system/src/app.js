const express = require("express");

const cors = require("cors");

const marketRoutes =
    require("./routes/marketRoutes");

const app = express();

app.use(cors());

app.use(express.json());

app.use("/market", marketRoutes);

module.exports = app;