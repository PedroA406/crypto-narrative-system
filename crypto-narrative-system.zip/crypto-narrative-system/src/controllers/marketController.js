const marketService =
    require("../services/marketService");

const Post =
    require("../models/Post");

async function getCoins(req, res) {

    try {

        const coins =
            await marketService.getAllCoins();

        res.status(200).json(coins);

    } catch (error) {

        res.status(500).json({
            error: error.message
        });

    }

}

async function getNews(req, res) {

    try {

        const news = await Post
            .find()
            .sort({ publishedAt: -1 })
            .limit(10);

        res.status(200).json(news);

    } catch (error) {

        res.status(500).json({
            error: error.message
        });

    }

}

module.exports = {

    getCoins,
    getNews

};